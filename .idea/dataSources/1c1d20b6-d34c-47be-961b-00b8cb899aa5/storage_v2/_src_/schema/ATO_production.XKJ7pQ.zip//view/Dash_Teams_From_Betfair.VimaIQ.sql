create definer = `admin-ATO`@`%` view Dash_Teams_From_Betfair as
select `vt`.`team_id`               AS `team_id`,
       `vt`.`bookie_id`             AS `bookie_id`,
       `vt`.`competition_id`        AS `competition_id`,
       `vt`.`sport_id`              AS `sport_id`,
       `vt`.`bookie_team_name`      AS `bookie_team_name`,
       `vt`.`normalized_team_name`  AS `normalized_team_name`,
       `vt`.`normalized_short_name` AS `normalized_short_name`,
       `vt`.`betfair_team_name`     AS `betfair_team_name`,
       `vt`.`status`                AS `status`,
       `vt`.`source`                AS `source`,
       `vt`.`numerical_team_id`     AS `numerical_team_id`,
       `vt`.`update_date`           AS `update_date`
from `ATO_production`.`V2_Teams` `vt`
where `vt`.`bookie_id` = 'BetfairExchange'
order by `vt`.`status` desc;

