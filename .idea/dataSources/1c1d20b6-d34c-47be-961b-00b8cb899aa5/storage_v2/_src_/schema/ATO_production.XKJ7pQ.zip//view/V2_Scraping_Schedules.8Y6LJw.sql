create definer = `admin-ATO`@`%` view V2_Scraping_Schedules as
with ScheduleLogic as (select `vmu`.`match_url_id`  AS `match_url_id`,
                              `vmu`.`match_id`      AS `match_id`,
                              `vm`.`date`           AS `date`,
                              `vmu`.`updated_date`  AS `updated_date`,
                              `vm`.`competition_id` AS `competition_id`,
                              `vm`.`sport_id`       AS `sport_id`,
                              `vmu`.`bookie_id`     AS `bookie_id`,
                              `vb`.`scraping_tool`  AS `scraping_tool`,
                              `vb`.`render_js`      AS `render_js`,
                              `vb`.`use_cookies`    AS `use_cookies`,
                              `vm`.`home_team`      AS `home_team`,
                              `vm`.`away_team`      AS `away_team`,
                              `vmu`.`web_url`       AS `web_url`,
                              `vb`.`scraping_group` AS `scraping_group`,
                              `vmu`.`http_status`   AS `http_status`,
                              case
                                  when timestampdiff(MINUTE, utc_timestamp(), `vm`.`date`) between 0 and 1 * 24 * 60 and
                                       timestampdiff(MINUTE, `vmu`.`updated_date`, utc_timestamp()) > 5 and
                                       `vmu`.`http_status` = 200 then 'A'
                                  when
                                      timestampdiff(MINUTE, utc_timestamp(), `vm`.`date`) between 1 * 24 * 60 and 2 * 24 * 60 and
                                      timestampdiff(MINUTE, `vmu`.`updated_date`, utc_timestamp()) > 15 and
                                      `vmu`.`http_status` = 200 then 'B'
                                  when
                                      timestampdiff(MINUTE, utc_timestamp(), `vm`.`date`) between 2 * 24 * 60 and 3 * 24 * 60 and
                                      timestampdiff(MINUTE, `vmu`.`updated_date`, utc_timestamp()) > 30 then 'C'
                                  when
                                      timestampdiff(MINUTE, utc_timestamp(), `vm`.`date`) between 3 * 24 * 60 and 5 * 24 * 60 and
                                      timestampdiff(MINUTE, `vmu`.`updated_date`, utc_timestamp()) > 120 or
                                      `vmu`.`http_status` <> 200 then 'D'
                                  when
                                      timestampdiff(MINUTE, utc_timestamp(), `vm`.`date`) between 5 * 24 * 60 and 7 * 24 * 60 and
                                      timestampdiff(MINUTE, `vmu`.`updated_date`, utc_timestamp()) > 720 then 'E'
                                  when `vmu`.`updated_date` is null then 'A'
                                  else NULL end     AS `frequency_group`
                       from (((`ATO_production`.`V2_Matches_Urls` `vmu` join `ATO_production`.`V2_Matches` `vm`
                               on (`vm`.`match_id` = `vmu`.`match_id`)) join `ATO_production`.`V2_Bookies` `vb`
                              on (`vb`.`bookie_id` = `vmu`.`bookie_id`)) join `ATO_production`.`V2_Competitions` `vc`
                             on (`vm`.`competition_id` = `vc`.`competition_id`))
                       where `vb`.`v2_ready` = 1
                         and `vm`.`sport_id` in ('1', '2')
                         and `vc`.`active` = 1
                         and timestampdiff(MINUTE, utc_timestamp(), `vm`.`date`) < 7 * 24 * 60)
select distinct `ScheduleLogic`.`match_url_id`                                                  AS `match_url_id`,
                `ScheduleLogic`.`match_id`                                                      AS `match_id`,
                `ScheduleLogic`.`date`                                                          AS `date`,
                `ScheduleLogic`.`updated_date`                                                  AS `updated_date`,
                if(`ScheduleLogic`.`frequency_group` is not null, 1, 0)                         AS `to_scrape`,
                `ScheduleLogic`.`frequency_group`                                               AS `frequency_group`,
                if(timestampdiff(MINUTE, utc_timestamp(), `ScheduleLogic`.`date`) < -120, 1, 0) AS `to_delete`,
                `ScheduleLogic`.`competition_id`                                                AS `competition_id`,
                `ScheduleLogic`.`sport_id`                                                      AS `sport_id`,
                `ScheduleLogic`.`bookie_id`                                                     AS `bookie_id`,
                `ScheduleLogic`.`scraping_tool`                                                 AS `scraping_tool`,
                `ScheduleLogic`.`render_js`                                                     AS `render_js`,
                `ScheduleLogic`.`use_cookies`                                                   AS `use_cookies`,
                `ScheduleLogic`.`home_team`                                                     AS `home_team`,
                `ScheduleLogic`.`away_team`                                                     AS `away_team`,
                `ScheduleLogic`.`web_url`                                                       AS `web_url`,
                `ScheduleLogic`.`scraping_group`                                                AS `scraping_group`
from `ScheduleLogic`
order by `ScheduleLogic`.`date`;

