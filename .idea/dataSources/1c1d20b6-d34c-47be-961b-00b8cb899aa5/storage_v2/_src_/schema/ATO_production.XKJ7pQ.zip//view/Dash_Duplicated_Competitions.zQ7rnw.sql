create definer = `admin-ATO`@`%` view Dash_Duplicated_Competitions as
select `ATO_production`.`V2_Competitions_Urls`.`bookie_id`      AS `bookie_id`,
       `ATO_production`.`V2_Competitions_Urls`.`competition_id` AS `competition_id`,
       count(0)                                                 AS `duplicate_count`
from `ATO_production`.`V2_Competitions_Urls`
group by `ATO_production`.`V2_Competitions_Urls`.`bookie_id`, `ATO_production`.`V2_Competitions_Urls`.`competition_id`
having count(0) > 1;

