create definer = `admin-ATO`@`%` view Dash_Date_Comparison as
select `vo`.`match_id`                     AS `match_id`,
       `vm`.`home_team`                    AS `home_team`,
       `vm`.`away_team`                    AS `away_team`,
       `vm`.`competition_id`               AS `competition_id`,
       max(`ve`.`date`)                    AS `betfair_date`,
       max(`vm`.`date`)                    AS `all_sport_date`,
       max(`ve`.`date`) - max(`vm`.`date`) AS `time_dif`
from ((`ATO_production`.`V2_Oddsmatcher` `vo` join `ATO_production`.`V2_Exchanges` `ve`
       on (`vo`.`bet_id` = `ve`.`bet_id`)) join `ATO_production`.`V2_Matches` `vm`
      on (`vo`.`match_id` = `vm`.`match_id`))
group by `vo`.`match_id`;

