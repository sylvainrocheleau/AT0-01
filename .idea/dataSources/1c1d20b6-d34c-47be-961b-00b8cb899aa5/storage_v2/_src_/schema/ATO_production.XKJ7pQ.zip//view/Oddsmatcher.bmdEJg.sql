create definer = `admin-ATO`@`%` view Oddsmatcher as
select `vm`.`date_es`                                     AS `Date`,
       `vs`.`sport_name_es`                               AS `Sport`,
       `vc`.`competition_name_es`                         AS `Competition`,
       concat(`vm`.`home_team`, ' vs ', `vm`.`away_team`) AS `Event`,
       `vo`.`rating_qualifying_bet`                       AS `RatingQualifyingBets`,
       `vo`.`rating_free_bet`                             AS `RatingFreeBets`,
       `vo`.`rating_refund_bet`                           AS `RatingRefundBets`,
       `vmo`.`market`                                     AS `Market`,
       `vmo`.`market_binary`                              AS `Market_Binary`,
       `vmo`.`result`                                     AS `Result`,
       `vb`.`bookie_name`                                 AS `Bookie`,
       `vo`.`back_odd`                                    AS `Back_Odds`,
       'Betfair Exchange'                                 AS `Exchange`,
       `vo`.`lay_odds`                                    AS `Lay_Odds`,
       `vo`.`liquidity`                                   AS `Liquidity`,
       `vmu`.`web_url`                                    AS `UrlBookie`,
       `vo`.`url`                                         AS `UrlExchange`
from ((((((`ATO_production`.`V2_Oddsmatcher` `vo` join `ATO_production`.`V2_Matches_Odds` `vmo`
           on (`vo`.`bet_id` = `vmo`.`bet_id` and `vo`.`bookie_id` = `vmo`.`bookie_id`)) join `ATO_production`.`V2_Matches` `vm`
          on (`vo`.`match_id` = `vm`.`match_id`)) join `ATO_production`.`V2_Sports` `vs`
         on (`vm`.`sport_id` = `vs`.`sport_id`)) join `ATO_production`.`V2_Competitions` `vc`
        on (`vm`.`competition_id` = `vc`.`competition_id`)) join `ATO_production`.`V2_Bookies` `vb`
       on (`vb`.`bookie_id` = `vo`.`bookie_id`)) join `ATO_production`.`V2_Matches_Urls` `vmu`
      on (`vmu`.`match_id` = `vmo`.`match_id` and `vo`.`bookie_id` = `vmu`.`bookie_id`))
where `vo`.`rating_qualifying_bet` < 105;

