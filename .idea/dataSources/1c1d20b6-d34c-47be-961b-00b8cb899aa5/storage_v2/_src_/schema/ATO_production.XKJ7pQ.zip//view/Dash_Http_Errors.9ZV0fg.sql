create definer = `admin-ATO`@`%` view Dash_Http_Errors as
select `c_urls`.`bookie_id`                                             AS `bookie_id`,
       coalesce(sum(case
                        when `c_urls`.`http_status` = 1200 and `c_urls`.`updated_date` is not null and
                             `c_urls`.`updated_date` < current_timestamp() - interval 2 hour and `v_comp`.`active` = 1
                            then 1
                        else 0 end), 0)                                 AS `comp_1200`,
       coalesce(sum(case
                        when `c_urls`.`http_status` = 1300 and `c_urls`.`updated_date` is not null and
                             `c_urls`.`updated_date` < current_timestamp() - interval 2 hour and `v_comp`.`active` = 1
                            then 1
                        else 0 end), 0)                                 AS `comp_1300`,
       coalesce(sum(case
                        when `c_urls`.`http_status` = 1500 and `c_urls`.`updated_date` is not null and
                             `c_urls`.`updated_date` < current_timestamp() - interval 2 hour and `v_comp`.`active` = 1
                            then 1
                        else 0 end), 0)                                 AS `comp_1500`,
       coalesce(sum(case
                        when `c_urls`.`http_status` = 1600 and `c_urls`.`updated_date` is not null and
                             `c_urls`.`updated_date` < current_timestamp() - interval 2 hour and `v_comp`.`active` = 1
                            then 1
                        else 0 end), 0)                                 AS `comp_1600`,
       coalesce((select sum(case
                                when `m_urls`.`http_status` = 1200 and `m_urls`.`updated_date` is not null and
                                     `m_urls`.`updated_date` < current_timestamp() - interval 2 hour and
                                     `v_comp2`.`active` = 1 then 1
                                else 0 end)
                 from ((`ATO_production`.`V2_Matches_Urls` `m_urls` join `ATO_production`.`V2_Matches` `m`
                        on (`m_urls`.`match_id` = `m`.`match_id`)) join `ATO_production`.`V2_Competitions` `v_comp2`
                       on (`m`.`competition_id` = `v_comp2`.`competition_id`))
                 where `m_urls`.`bookie_id` = `c_urls`.`bookie_id`), 0) AS `matches_1200`,
       coalesce((select sum(case
                                when `m_urls`.`http_status` = 1600 and `m_urls`.`updated_date` is not null and
                                     `m_urls`.`updated_date` < current_timestamp() - interval 2 hour and
                                     `v_comp2`.`active` = 1 then 1
                                else 0 end)
                 from ((`ATO_production`.`V2_Matches_Urls` `m_urls` join `ATO_production`.`V2_Matches` `m`
                        on (`m_urls`.`match_id` = `m`.`match_id`)) join `ATO_production`.`V2_Competitions` `v_comp2`
                       on (`m`.`competition_id` = `v_comp2`.`competition_id`))
                 where `m_urls`.`bookie_id` = `c_urls`.`bookie_id`), 0) AS `matches_1600`,
       coalesce((select sum(case
                                when `m_urls`.`http_status` = 403 and `m_urls`.`updated_date` is not null and
                                     `m_urls`.`updated_date` < current_timestamp() - interval 2 hour and
                                     `v_comp2`.`active` = 1 then 1
                                else 0 end)
                 from ((`ATO_production`.`V2_Matches_Urls` `m_urls` join `ATO_production`.`V2_Matches` `m`
                        on (`m_urls`.`match_id` = `m`.`match_id`)) join `ATO_production`.`V2_Competitions` `v_comp2`
                       on (`m`.`competition_id` = `v_comp2`.`competition_id`))
                 where `m_urls`.`bookie_id` = `c_urls`.`bookie_id`), 0) AS `matches_403`,
       coalesce((select sum(case
                                when `m_urls`.`http_status` = 404 and `m_urls`.`updated_date` is not null and
                                     `m_urls`.`updated_date` < current_timestamp() - interval 2 hour and
                                     `v_comp2`.`active` = 1 then 1
                                else 0 end)
                 from ((`ATO_production`.`V2_Matches_Urls` `m_urls` join `ATO_production`.`V2_Matches` `m`
                        on (`m_urls`.`match_id` = `m`.`match_id`)) join `ATO_production`.`V2_Competitions` `v_comp2`
                       on (`m`.`competition_id` = `v_comp2`.`competition_id`))
                 where `m_urls`.`bookie_id` = `c_urls`.`bookie_id`), 0) AS `matches_404`
from (`ATO_production`.`V2_Competitions_Urls` `c_urls` join `ATO_production`.`V2_Competitions` `v_comp`
      on (`c_urls`.`competition_id` = `v_comp`.`competition_id`))
where `v_comp`.`active` = 1
group by `c_urls`.`bookie_id`;

