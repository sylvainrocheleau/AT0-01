create definer = `admin-ATO`@`%` view Dash_Average_Crawl_Times as
select coalesce(`vss`.`bookie_id`, 'Overall')                                                                     AS `bookie_id`,
       coalesce(`vss`.`scraping_group`)                                                                           AS `scraping_group`,
       sec_to_time(floor(avg(case
                                 when `vss`.`date` between current_timestamp() and current_timestamp() + interval 24 hour
                                     then timestampdiff(SECOND, `vss`.`updated_date`, current_timestamp()) end))) AS `freq_A`,
       sec_to_time(floor(avg(case
                                 when `vss`.`date` between current_timestamp() + interval 24 hour and current_timestamp() + interval 48 hour
                                     then timestampdiff(SECOND, `vss`.`updated_date`, current_timestamp()) end))) AS `freq_B`,
       sec_to_time(floor(avg(case
                                 when `vss`.`date` between current_timestamp() + interval 48 hour and current_timestamp() + interval 72 hour
                                     then timestampdiff(SECOND, `vss`.`updated_date`, current_timestamp()) end))) AS `freq_C`,
       sec_to_time(floor(avg(case
                                 when `vss`.`date` between current_timestamp() + interval 72 hour and current_timestamp() + interval 120 hour
                                     then timestampdiff(SECOND, `vss`.`updated_date`, current_timestamp()) end))) AS `freq_D`,
       sec_to_time(floor(avg(case
                                 when `vss`.`date` between current_timestamp() + interval 120 hour and current_timestamp() + interval 168 hour
                                     then timestampdiff(SECOND, `vss`.`updated_date`, current_timestamp()) end))) AS `freq_E`
from (`ATO_production`.`V2_Scraping_Schedules` `vss` join `ATO_production`.`V2_Matches_Urls` `vmu`
      on (`vss`.`match_url_id` = `vmu`.`match_url_id`))
where `vss`.`date` between current_timestamp() and current_timestamp() + interval 168 hour
  and `vmu`.`http_status` = 200
group by `vss`.`bookie_id`
with rollup;

