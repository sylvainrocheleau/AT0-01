create definer = `admin-ATO`@`%` view V2_MatchUrl_NotIn_WebUrl_Count as
select `ATO_production`.`V2_Matches_Urls`.`bookie_id` AS `bookie_id`, count(0) AS `mismatch_count`
from `ATO_production`.`V2_Matches_Urls`
where `ATO_production`.`V2_Matches_Urls`.`web_url` is null
   or `ATO_production`.`V2_Matches_Urls`.`web_url` not like
      concat('%', `ATO_production`.`V2_Matches_Urls`.`match_url_id`, '%')
group by `ATO_production`.`V2_Matches_Urls`.`bookie_id`;

