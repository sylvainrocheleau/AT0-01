create definer = `admin-ATO`@`%` view Dutcher as
select `vm`.`date`                                        AS `Date`,
       `vs`.`sport_name_es`                               AS `Sport`,
       `vc`.`competition_name_es`                         AS `Competition`,
       concat(`vm`.`home_team`, ' vs ', `vm`.`away_team`) AS `Event`,
       `vd`.`rating_qualifying_bets`                      AS `RatingQualifyingBets`,
       `vd`.`rating_free_bets`                            AS `RatingFreeBets`,
       `vd`.`rating_refund_bets`                          AS `RatingRefundBets`,
       `vmo1`.`market`                                    AS `Market`,
       `vmo1`.`market_binary`                             AS `Market_Binary`,
       `vmo1`.`result`                                    AS `Result1`,
       `vmo1`.`back_odd`                                  AS `Back_Odds1`,
       `vd`.`bookie_id`                                   AS `Bookie1`,
       `vd`.`result_2`                                    AS `Result2`,
       `vd`.`back_odds_2`                                 AS `Back_Odds2`,
       `vd`.`bookie_2`                                    AS `Bookie2`,
       `vd`.`url_1`                                       AS `Url1`,
       `vd`.`url_2`                                       AS `Url2`
from ((((`ATO_production`.`V2_Dutcher` `vd` join `ATO_production`.`V2_Matches` `vm`
         on (`vd`.`match_id` = `vm`.`match_id`)) join `ATO_production`.`V2_Competitions` `vc`
        on (`vm`.`competition_id` = `vc`.`competition_id`)) join `ATO_production`.`V2_Matches_Odds` `vmo1`
       on (`vd`.`bookie_id` = `vmo1`.`bookie_id` and
           `vmo1`.`bet_id` = `vd`.`bet_id`)) join `ATO_production`.`V2_Sports` `vs`
      on (`vm`.`sport_id` = `vs`.`sport_id`))
where `vd`.`rating_qualifying_bets` < 105;

