create definer = `admin-ATO`@`%` view Dash_Missing_Odds as
select `mo`.`match_id`                                                   AS `match_id`,
       `mo`.`bookie_id`                                                  AS `bookie_id`,
       `m`.`sport_id`                                                    AS `sport_id`,
       `mu`.`match_url_id`                                               AS `match_url_id`,
       case
           when `m`.`sport_id` = 1 then case
                                            when
                                                sum(case when `mo`.`market` = 'Ganador del partido' then 1 else 0 end) =
                                                0 then 'Ganador del partido'
                                            when sum(case when `mo`.`market` = 'Marcador Exacto' then 1 else 0 end) = 0
                                                then 'Marcador Exacto'
                                            when sum(case when `mo`.`market` like 'Más/Menos%' then 1 else 0 end) = 0
                                                then 'Más/Menos' end
           when `m`.`sport_id` = 2 then case
                                            when sum(case when `mo`.`market` = 'Ganador sin empate' then 1 else 0 end) = 0
                                                then 'Ganador sin empate'
                                            when sum(case when `mo`.`market` like 'Más/Menos%' then 1 else 0 end) = 0
                                                then 'Más/Menos' end end AS `condition_not_met`
from ((`ATO_production`.`V2_Matches_Odds` `mo` join `ATO_production`.`V2_Matches` `m`
       on (`mo`.`match_id` = `m`.`match_id`)) join `ATO_production`.`V2_Matches_Urls` `mu`
      on (`mo`.`match_id` = `mu`.`match_id` and `mo`.`bookie_id` = `mu`.`bookie_id`))
where `m`.`sport_id` in (1, 2)
group by `mo`.`match_id`, `mo`.`bookie_id`, `mu`.`match_url_id`, `m`.`sport_id`
having `m`.`sport_id` = 1 and (sum(case when `mo`.`market` = 'Ganador del partido' then 1 else 0 end) = 0 or
                               sum(case when `mo`.`market` = 'Marcador Exacto' then 1 else 0 end) = 0 or
                               sum(case when `mo`.`market` like 'Más/Menos%' then 1 else 0 end) = 0)
    or `m`.`sport_id` = 2 and (sum(case when `mo`.`market` = 'Ganador sin empate' then 1 else 0 end) = 0 or
                               sum(case when `mo`.`market` like 'Más/Menos%' then 1 else 0 end) = 0);

