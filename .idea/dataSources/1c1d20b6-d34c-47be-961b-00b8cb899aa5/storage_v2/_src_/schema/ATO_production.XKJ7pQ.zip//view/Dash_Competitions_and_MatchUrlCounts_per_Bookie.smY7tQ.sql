create definer = spider_rw_03@`%` view Dash_Competitions_and_MatchUrlCounts_per_Bookie as
select `b`.`bookie_id`                                            AS `bookie_id`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'Argentina-PrimeraDivision'
        limit 1)                                                  AS `Argentina-PrimeraDivision_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'Argentina-PrimeraDivision') AS `Argentina-PrimeraDivision_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'Argentina-PrimeraDivision'
        limit 1)                                                  AS `Argentina-PrimeraDivision_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'ATP'
        limit 1)                                                  AS `ATP_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'ATP')                       AS `ATP_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'ATP'
        limit 1)                                                  AS `ATP_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'BillieJeanKingCup'
        limit 1)                                                  AS `BillieJeanKingCup_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'BillieJeanKingCup')         AS `BillieJeanKingCup_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'BillieJeanKingCup'
        limit 1)                                                  AS `BillieJeanKingCup_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'Challenger'
        limit 1)                                                  AS `Challenger_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'Challenger')                AS `Challenger_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'Challenger'
        limit 1)                                                  AS `Challenger_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'CONMEBOL-CopaLibertadores'
        limit 1)                                                  AS `CONMEBOL-CopaLibertadores_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'CONMEBOL-CopaLibertadores') AS `CONMEBOL-CopaLibertadores_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'CONMEBOL-CopaLibertadores'
        limit 1)                                                  AS `CONMEBOL-CopaLibertadores_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'CopadelaLigaInglesa'
        limit 1)                                                  AS `CopadelaLigaInglesa_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'CopadelaLigaInglesa')       AS `CopadelaLigaInglesa_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'CopadelaLigaInglesa'
        limit 1)                                                  AS `CopadelaLigaInglesa_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'CopaItalia'
        limit 1)                                                  AS `CopaItalia_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'CopaItalia')                AS `CopaItalia_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'CopaItalia'
        limit 1)                                                  AS `CopaItalia_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'CopaSudamericana'
        limit 1)                                                  AS `CopaSudamericana_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'CopaSudamericana')          AS `CopaSudamericana_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'CopaSudamericana'
        limit 1)                                                  AS `CopaSudamericana_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'LaLigaEspanola'
        limit 1)                                                  AS `LaLigaEspanola_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'LaLigaEspanola')            AS `LaLigaEspanola_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'LaLigaEspanola'
        limit 1)                                                  AS `LaLigaEspanola_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'Ligue1Francesa'
        limit 1)                                                  AS `Ligue1Francesa_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'Ligue1Francesa')            AS `Ligue1Francesa_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'Ligue1Francesa'
        limit 1)                                                  AS `Ligue1Francesa_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'MajorLeagueSoccerUSA'
        limit 1)                                                  AS `MajorLeagueSoccerUSA_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'MajorLeagueSoccerUSA')      AS `MajorLeagueSoccerUSA_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'MajorLeagueSoccerUSA'
        limit 1)                                                  AS `MajorLeagueSoccerUSA_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'Partidosamistosos'
        limit 1)                                                  AS `Partidosamistosos_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'Partidosamistosos')         AS `Partidosamistosos_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'Partidosamistosos'
        limit 1)                                                  AS `Partidosamistosos_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'PremierLeagueInglesa'
        limit 1)                                                  AS `PremierLeagueInglesa_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'PremierLeagueInglesa')      AS `PremierLeagueInglesa_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'PremierLeagueInglesa'
        limit 1)                                                  AS `PremierLeagueInglesa_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'SegundaDivisionEspanola'
        limit 1)                                                  AS `SegundaDivisionEspanola_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'SegundaDivisionEspanola')   AS `SegundaDivisionEspanola_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'SegundaDivisionEspanola'
        limit 1)                                                  AS `SegundaDivisionEspanola_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'SerieABrasil'
        limit 1)                                                  AS `SerieABrasil_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'SerieABrasil')              AS `SerieABrasil_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'SerieABrasil'
        limit 1)                                                  AS `SerieABrasil_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'SupercopadeEuropa'
        limit 1)                                                  AS `SupercopadeEuropa_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'SupercopadeEuropa')         AS `SupercopadeEuropa_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'SupercopadeEuropa'
        limit 1)                                                  AS `SupercopadeEuropa_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'UEFAChampionsLeague'
        limit 1)                                                  AS `UEFAChampionsLeague_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'UEFAChampionsLeague')       AS `UEFAChampionsLeague_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'UEFAChampionsLeague'
        limit 1)                                                  AS `UEFAChampionsLeague_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'UEFAConferenceLeague'
        limit 1)                                                  AS `UEFAConferenceLeague_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'UEFAConferenceLeague')      AS `UEFAConferenceLeague_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'UEFAConferenceLeague'
        limit 1)                                                  AS `UEFAConferenceLeague_url`,
       (select min(`cu`.`http_status`)
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'UEFAEuropaLeague'
        limit 1)                                                  AS `UEFAEuropaLeague_status`,
       (select count(distinct `mu`.`match_url_id`)
        from (`ATO_production`.`V2_Matches_Urls` `mu` join `ATO_production`.`V2_Matches` `m`
              on (`mu`.`match_id` = `m`.`match_id`))
        where `mu`.`bookie_id` = `b`.`bookie_id`
          and `m`.`competition_id` = 'UEFAEuropaLeague')          AS `UEFAEuropaLeague_count`,
       (select `cu`.`competition_url_id`
        from `ATO_production`.`V2_Competitions_Urls` `cu`
        where `cu`.`bookie_id` = `b`.`bookie_id`
          and `cu`.`competition_id` = 'UEFAEuropaLeague'
        limit 1)                                                  AS `UEFAEuropaLeague_url`
from `ATO_production`.`V2_Bookies` `b`
where `b`.`v2_ready` = 1
  and `b`.`bookie_id` <> 'AllSportAPI';

